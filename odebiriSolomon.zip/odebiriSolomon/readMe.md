# FileStatistic
FileStatistic is a simple console java program that reads (selected) files of a particular directory passed into it as argument from the console.

## Libraries
 (in ./lib/) pdfbox 3.0 to parse pdf file [org.apache.*]

## Usage
 Load the program from the console. 
 Insert a valid directory as argument on prompt load 
